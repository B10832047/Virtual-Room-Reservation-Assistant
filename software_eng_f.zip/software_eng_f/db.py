import sqlite3

import click
from flask import Flask
from flask import current_app
from flask.cli import with_appcontext
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import db


class Account(db.Model):
    __tablename__ = 'account'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(128), unique=True)
    password = db.Column(db.String(128), unique=False)

    def __init__(self, name_temp, password_temp):
        self.name = name_temp
        self.password = password_temp
        
class Event(db.Model):
    __tablename__ = 'event'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    event_id = db.Column(db.String(128), unique=False)
    room_id = db.Column(db.Integer, unique=False)
    date = db.Column(db.String(128), unique=False)
    start_time = db.Column(db.String(128), unique=False)
    end_time = db.Column(db.String(128), unique=False)
    organiser = db.Column(db.String(128), unique=False)
    participant = db.Column(db.String(256), unique=False)
    purpose = db.Column(db.String(128), unique=False)
    remark = db.Column(db.String(128), unique=False)

    def __init__(self,
                    event_id_temp,
                    room_id_temp,
                    date_temp,
                    start_time_temp,
                    end_time_temp,
                    organiser_temp,
                    participant_temp,
                    purpose_temp,
                    remark_temp):
        self.event_id = event_id_temp
        self.room_id = room_id_temp
        self.date = date_temp
        self.start_time = start_time_temp
        self.end_time = end_time_temp
        self.organiser = organiser_temp
        self.participant = participant_temp
        self.purpose = purpose_temp
        self.remark = remark_temp

db.create_all()

'''
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    
    return g.db

def close_db(e=None):
    db = g.pop('db', None)

    if db is not None:
        db.close()

def init_db():
    db = get_db()

    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))

@click.command('init-db')
@with_appcontext
def init_db_command():
    """clear the existing data and create new tables."""
    init_db()
    click.echo('Initialized the database.')

def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
'''
