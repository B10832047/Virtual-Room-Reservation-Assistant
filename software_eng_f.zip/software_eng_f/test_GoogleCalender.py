from __future__ import print_function
import datetime
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from db import Account, Event
import ast

# If modifying these scopes, delete the file token.json.
SCOPES = ["https://www.googleapis.com/auth/calendar.events", "https://www.googleapis.com/auth/calendar.events.readonly", "https://www.googleapis.com/auth/calendar"]


def main(app_event, username):
    """Shows basic usage of the Google Calendar API.
    Prints the start and name of the next 10 events on the user's calendar.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token{name}.json'.format(name=username)):
        creds = Credentials.from_authorized_user_file('token{name}.json'.format(name=username), SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=8080)
        # Save the credentials for the next run
        with open('token{name}.json'.format(name=username), 'w') as token:
            token.write(creds.to_json())

    service = build('calendar', 'v3', credentials=creds)

    # Call the Calendar API
    """ now = datetime.datetime.utcnow().isoformat() + 'Z' # 'Z' indicates UTC time
    print('Getting the upcoming 10 events')
    events_result = service.events().list(calendarId='primary', timeMin=now,
                                        maxResults=10, singleEvents=True,
                                        orderBy='startTime').execute()
    events = events_result.get('items', [])

    if not events:
        print('No upcoming events found.')
    for event in events:
        start = event['start'].get('dateTime', event['start'].get('date'))
        print(start, event['summary']) """


    result = service.calendarList().list().execute()
    #print(result['items'])
    tmp_list = ast.literal_eval(app_event.participant)
    print("tmp = ", tmp_list)
    email_list = list()
    for x in tmp_list:
      dic = {}
      if x != "":
        dic['email'] = x
        email_list.append(dic)

    #事件模板
    event = {
      'summary': 'meeting at '+str(app_event.room_id),
      'location': 'Taipei',
      'description': app_event.remark,
      'start': {
        'dateTime': app_event.date+"T"+app_event.start_time,
        'timeZone': 'Asia/Taipei',
      },
      'end': {
        'dateTime': app_event.date+"T"+app_event.end_time,
        'timeZone': 'Asia/Taipei',
      },
      #'recurrence': [
      #  'RRULE:FREQ=DAILY;COUNT=2'
      #],
      'reminders': {
        'useDefault': True,
        #'overrides': [
        #  {'method': 'email', 'minutes': 24 * 60},
        #  {'method': 'popup', 'minutes': 10},
        #],
      },
    }
    event['attendees'] = email_list
    print('email list: ', event['attendees'])
    calendar_id = result['items'][0]['id']
    print(calendar_id)
    newEvent = service.events().insert(calendarId=calendar_id, body=event, sendUpdates='all').execute()
    return newEvent
    #檢查事件是否加入
    #now = datetime.datetime.utcnow().isoformat() + 'Z'
    #events_result = service.events().list(calendarId='primary', timeMin=now,
    #                                   maxResults=10, singleEvents=True,
    #                                    orderBy='startTime').execute()
    #events = events_result.get('items', [])
    #if not events:
    #    print('No upcoming events found.')
    #for event in events:
    #    start = event['start'].get('dateTime', event['start'].get('date'))
    #    print(start, event['summary'])
    #    print(event)
    

# if __name__ == '__main__':
#     main()