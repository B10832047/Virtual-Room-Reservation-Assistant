from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow

scopes = {"https://www.googleapis.com/auth/calendar.events"}
flow = InstalledAppFlow.from_client_secrets_file("credentials.json", scopes = scopes)
import pickle
credentials = flow.run_console()
service = build("calendar", "v3", credentials = credentials)