from dataclasses import replace
import os
from flask import Flask, redirect, url_for, request, render_template, session, jsonify
from flask import flash
from werkzeug.security import check_password_hash, generate_password_hash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import exc
from config import app, db
from db import Account, Event
import json
import test_GoogleCalender as gapi
import ast
from flask import Response
import apiSearch as gapimodify
import smtplib, ssl
from email.message import EmailMessage


def send_email(event_type, p_list, room_id, date, start_t, end_t, organiser, purpose, remark):
    print('寄信debug')
    print(p_list)
    if remark == "":
        remark = '無'
    if event_type == 0:
        subject = "會議建立通知"
        head = "本次"
    else:
        subject = "會議取消通知"
        head = "取消"

    for email in p_list:
        if email != "":
            msg = EmailMessage()
            msg_body = head + "會議的資訊如下：\n" + "主辦人: " + organiser + '\n' + "會議室編號: " + str(room_id) + '\n' + "日期: " + date + '\n' + '開始時間: ' + str(start_t) + '\n' + '結束時間: ' + str(end_t) + '\n' + '使用目的: ' + purpose + '\n' + "備註： " + remark
            msg.set_content(msg_body)
            msg["Subject"] = subject
            msg["From"] = "b10832023@gapps.ntust.edu.tw"
            msg["To"] = email
            context=ssl.create_default_context()
            with smtplib.SMTP("smtp.gmail.com", port=587) as smtp:
                smtp.ehlo()
                smtp.starttls(context=context)
                smtp.login("b10832023@gapps.ntust.edu.tw", "86619345")
                smtp.login(msg["From"], "p@55w0rd")
                smtp.send_message(msg)


class UpdateConflictErr(Exception):
    def __init__(self) -> None:
        message = ""
        super().__init__(message)

class EventEmptyErr(Exception):
    def __init__(self) -> None:
        message = ""
        super().__init__(message)



@app.route('/getAttendence', methods = ['POST'])
def getAttendce():
    for x in request.form:
        print("有啥", x, request.form[x])
    eid = request.form['event id']
    print('id is ', id)
    target = Event.query.filter_by(event_id = eid).first()
    tmp = list()
    print("target: ", target.participant)
    emails = ""
    if target.participant != "":
        emails = ast.literal_eval(target.participant)
    print("emails  " , emails, "type: ", type(emails))
    for x in emails:
        tmp_d = dict()
        tmp_d['email'] = x
        tmp.append(tmp_d)
    print(tmp)
    return Response(json.dumps(tmp),  mimetype='application/json')



@app.route('/getEvent', methods = ['POST'])
def getEvent():
    for x in request.form:
        print("有啥", x, request.form[x])
    eid = request.form['event id']
    print('id is ', id)
    target = Event.query.filter_by(event_id = eid).first()
    tmp = list()
    tmp.append(target.date)
    tmp.append(target.start_time)
    tmp.append(target.end_time)
    tmp.append(target.purpose)
    tmp.append(target.remark)
    tmp.append(target.participant)
    return jsonify(tmp)



@app.route('/modify', methods = ('GET', 'POST'))
def modify(): 
    # logging.info("Modify")
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        print("username in session")
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

        # 查詢該使用者主辦的所有會議
        event_list = Event.query.filter_by(organiser=session['username']).all()
        event_id = []
        # 將會議事件的id加入選擇清單
        for event in event_list:
            event_id.append(event.event_id)

        error = None
        # 沒有任何會議可供編輯
        if event_list == None:
            # 需要將錯誤訊息回傳網頁
            error = "You don't have any meeting to edit."
            return redirect(url_for("Inquire"))


        if request.method == 'POST':
            print("Get Post. print name in request form:")
            for name in request.form:
                print(name)
            _id = request.form['event id']
            _option = request.form['option'] # Update / Delete / Attendee Delete
            if _option == "Delete":
                # 發送會議取消通知信
                delete_event = Event.query.filter_by(event_id=_id).first()
                event_type = 1
                p_list = ast.literal_eval(delete_event.participant)
                p_list.append(delete_event.organiser)
                send_email(event_type, p_list, delete_event.room_id, delete_event.date, delete_event.start_time, delete_event.end_time, delete_event.organiser, delete_event.purpose, delete_event.remark)

                # 刪除該會議事件
                Event.query.filter_by(event_id=_id).delete()
                db.session.commit()

                # 更新google calendar
                gapimodify.main(_option, _id, session['username'], event.participant, event.date, event.start_time, event.end_time,event.purpose, event.remark)
                event_list = Event.query.filter_by(organiser=session['username']).all()
                event_id = []
                for event in event_list:
                    event_id.append(event.event_id)
            elif _option == "Update":
                _date = request.form['date']
                _purpose = request.form['purpose']
                _remark = request.form['remark']
                print("Get option.")
                _new_participant = request.form.getlist('email')
                print(_new_participant)
                print("Start filter.")
                event_to_change = Event.query.filter_by(event_id=_id).first()  #目前欲更改之事件
                print("Get event_to_change.")
                print("型態", type(event_to_change.participant), " ", event_to_change.participant)
                p_list = eval(event_to_change.participant)#將要修改的事件參加者轉為list
                
                _participant = list(set(_new_participant).union(p_list))#合併list

                print("參加者名單", _participant)
                print("set event_to_change.participant")
                time = request.form.get('time')
                if time != None:
                    time = int(time)
                    _start_t = f'{(6 + time*2):02d}:00:00'
                    _end_t = f'{(8 + time*2):02d}:00:00'
                print("Update")
                try:
                    update_event(event_to_change, _participant, _date, _start_t, _end_t, _purpose, _remark)
                except EventEmptyErr:
                    error = "Event ID error."
                except UpdateConflictErr:
                    error = "event conflict."
                flash(error, 'info')
                print("Error:", error)
                if error == None:
                    gapimodify.main(_option, _id, session['username'], _participant, _date, _start_t, _end_t, _purpose, _remark)

            else:  #刪除參加者
                _new_participant = request.form.getlist('attendee')
                for x in _new_participant:
                    x.replace("\"", "")
                print("新來的", type(_new_participant))
                participant = eval(event.participant)
                print("新來的", type(_new_participant), " ", _new_participant)
                print("原來:", participant)
                for p in _new_participant:
                    if p!='' and p in participant:
                        participant.remove(p)
                print("Result: ", participant)
                event.participant = str(participant)
                db.session.commit()
                gapimodify.main(_option, _id, session['username'], str(_new_participant), event.date, event.start_time, event.end_time,event.purpose, event.remark)
            print("Return template of post.")
        return render_template("modify.html", event_id=event_id, login_or_not=login_or_not, login=login, error=error)
    else:
        return redirect(url_for("login"))

# 更新會議事件，由編輯會議的網頁後台呼叫
def update_event(event_to_change, _participant, _date, _start_t, _end_t, _purpose, _remark) -> None:
    print(f"all participant of event_to_change: {_participant}")
    if event_to_change == None:
        raise EventEmptyErr
    if _date != '':
        if _date != event_to_change.date:
            conflict = False
            same_time_event = Event.query.filter_by(start_time=_start_t, date=_date).all()
            for event in same_time_event:
                if event.participant != "": # 使用者時段衝突
                    participant = eval(event.participant)
                    all_people = participant
                    all_people.append(event.organiser)
                    print(f"event.organiser: {event.organiser}, all_people: {all_people}, participant: {participant}, _participant: {_participant}")
                    print(f"list(set(participant).intersection(_participant)): {list(set(all_people).intersection(_participant))}")
                    conflict = True if list(set(all_people).intersection(_participant))!=None else False # 若目前事件的人員在該時間有其他預約紀錄，則衝突
                if event.room_id == event_to_change.room_id: # 同時段欲更改事件的房間有被預約，則衝突
                    conflict = True
                if conflict == True: # 若衝突則不繼續判斷
                    raise UpdateConflictErr
    if _purpose != None: # 若值為空，不覆寫
        event_to_change.purpose = _purpose
    if _participant != None:
        p_list = _participant
        event_to_change.participant = str(_participant)
    if _remark != None:
        event_to_change.remark = _remark
    event_to_change.date = _date
    event_to_change.start_time = _start_t
    event_to_change.end_time = _end_t

    # 發送會議建立通知信
    event_type = 0
    p_list.append(event_to_change.organiser)
    send_email(event_type, p_list, event_to_change.room_id, event_to_change.date, event_to_change.start_time, event_to_change.end_time, event_to_change.organiser, event_to_change.purpose, event_to_change.remark)
    db.session.commit()
    return 


# 查詢會議室目前預約狀況的網站
@app.route('/search')
def search():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

    return render_template("search.html", login_or_not=login_or_not, login=login)


# 顯示個人行事曆的網頁
@app.route('/')
def catalog():
    # result = Event.query.filter_by(room_id='2').all()  #用房號過濾
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"
        result = Event.query.filter_by(organiser=session['username']).all()

        # 搜尋所有事件，取得此使用者為參與者身分的所有事件
        all_event = Event.query.all()
        for e in all_event:
            if e.participant != "":
                print("p = ", e.participant)
                ep_list = ast.literal_eval(e.participant)
                if session['username'] in ep_list:
                    result.append(e)
                    continue

        schedule = list()
        for s in result:
            # 測試用
            print('scheduld:', s.event_id)
            print(s.room_id)
            print(s.date)
            print(s.start_time)
            print(s.end_time)
            print(s.organiser)
            print(s.participant)
            print(s.purpose)
            print(s.remark)
            print(s.remark+"Event_id: {eid}".format(eid = s.event_id))
            tmp = {
                "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
                "start": s.date+'T'+s.start_time,
                "end": s.date+'T'+s.end_time
            }
            schedule.append(tmp)
        schedule = str(schedule).replace('True', 'true').replace('None', 'null')
        return render_template("catalog.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)
    return render_template("catalog.html.jinja", schedule='null', login_or_not=login_or_not, login=login)


# 會議室1的行事曆
@app.route('/catalog_r1', methods=['GET'])
def catalog_r1():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

    # 從事件資料庫搜尋舉辦於會議室1的所有事件
    result = Event.query.filter_by(room_id=1).all()
    schedule = list()
    for s in result:
        tmp = {
            "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
            "start": s.date+'T'+s.start_time,
            "end": s.date+'T'+s.end_time
        }
        schedule.append(tmp)
    schedule = str(schedule).replace('True', 'true').replace('None', 'null')
    return render_template("catalog_r1.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)

# 會議室2的行事曆
@app.route('/catalog_r2', methods=('GET', 'POST'))
def catalog_r2():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        error = None
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

    # 從事件資料庫搜尋舉辦於會議室2的所有事件
    result = Event.query.filter_by(room_id=2).all()
    schedule = list()
    for s in result:
        tmp = {
            "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
            "start": s.date+'T'+s.start_time,
            "end": s.date+'T'+s.end_time
        }
        schedule.append(tmp)
    schedule = str(schedule).replace('True', 'true').replace('None', 'null')
    return render_template("catalog_r2.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)

# 會議室3的行事曆
@app.route('/catalog_r3', methods=('GET', 'POST'))
def catalog_r3():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        error = None
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

    # 從事件資料庫搜尋舉辦於會議室3的所有事件
    result = Event.query.filter_by(room_id=3).all()
    schedule = list()
    for s in result:
        tmp = {
            "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
            "start": s.date+'T'+s.start_time,
            "end": s.date+'T'+s.end_time
        }
        schedule.append(tmp)
    schedule = str(schedule).replace('True', 'true').replace('None', 'null')
    return render_template("catalog_r3.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)


# 會議室4的行事曆
@app.route('/catalog_r4', methods=('GET', 'POST'))
def catalog_r4():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        error = None
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

        # 從事件資料庫搜尋舉辦於會議室4的所有事件
    result = Event.query.filter_by(room_id=4).all()
    schedule = list()
    for s in result:
        tmp = {
            "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
            "start": s.date+'T'+s.start_time,
            "end": s.date+'T'+s.end_time
        }
        schedule.append(tmp)
    schedule = str(schedule).replace('True', 'true').replace('None', 'null')
    return render_template("catalog_r4.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)


# 會議室5的行事曆
@app.route('/catalog_r5', methods=('GET', 'POST'))
def catalog_r5():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        error = None
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"

    # 從事件資料庫搜尋舉辦於會議室5的所有事件
    result = Event.query.filter_by(room_id=5).all()
    schedule = list()
    for s in result:
        tmp = {
            "title": s.remark+"  Event_id: {eid}".format(eid = s.event_id),
            "start": s.date+'T'+s.start_time,
            "end": s.date+'T'+s.end_time
        }
        schedule.append(tmp)
    schedule = str(schedule).replace('True', 'true').replace('None', 'null')
    return render_template("catalog_r5.html.jinja", schedule=schedule, login_or_not=login_or_not, login=login)


# 預約以及查詢預約狀況的網頁
@app.route('/Inquire', methods=('GET', 'POST'))
def Inquire():
    login_or_not = '/auth/login'
    login = 'login'
    if 'username' in session:
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"
        error = None

        if request.method == 'POST':
            p_list = request.form.getlist('email')
            print(p_list)
            _start_t = 0
            _end_t = 0
            _room_id = request.form['room_id']
            _organiser = session['username']
            _purpose = request.form['purpose']
            _remark = request.form['remark']
            _date = request.form['date']

            for data in request.form:
                # 測試用
                print("data in form:", data,  request.form[data])

            time = request.form.get('time')
            if time != None:
                time = int(time)
                _start_t = f'{(6 + time*2):02d}:00:00'
                _end_t = f'{(8 + time*2):02d}:00:00'

            # 判定參與者是否和自身參與的其他會議衝突
            flag = []
            for i in range(len(p_list)):
                if p_list[i] != '':
                    flag.append('0')
            p2_list = []
            e_list = Event.query.filter_by(start_time=_start_t, date= _date).all()
            print('e_list: ')
            print(e_list)
            for e in e_list:
                if e.participant != "":
                    print("p = ", e.participant)
                    ep_list = ast.literal_eval(e.participant)
                    for p_index in range(len(p_list)):
                        if p_list[p_index] in ep_list:
                            flag[p_index] = '1'
            # 判定參與者是否和自身主辦的其他會議衝突
            for p_index in range(len(p_list)):
                e = None
                e = Event.query.filter_by(organiser=p_list[p_index], start_time=_start_t, date=_date).first()
                if e != None:
                    flag[p_index] = '1'

            print('p_list[0]' + str(p_list[0]))
            for i in range(len(flag)):
                print('flag' + str(i)+': ' + str(flag[i]))
                if flag[i] == '0':
                    print('p_list' + str(i) + ': ' + str(p_list[i]))
                    p2_list.append(p_list[i])
            _participant = str(p2_list)
            print('p2_list')
            print(p2_list)
            print(_participant)
 
            error = None
            conflict1 = None
            conflict2 = None
            conflict3 = None
            # 依據房號、日期、開始時間判斷Event是否衝突
            conflict1 = Event.query.filter_by(room_id=_room_id, start_time=_start_t, date= _date).first()
            # 依據主辦人、日期、開始時間判斷Event是否衝突
            conflict2 = Event.query.filter_by(organiser=session['username'], start_time=_start_t, date=_date).first()

            e_list = Event.query.filter_by(start_time=_start_t, date=_date).all()
            for e in e_list:
                if e.participant != "":
                    ep_list = ast.literal_eval(e.participant)
                    if session['username'] in ep_list:
                        conflict3 = "Yes"
                        break
            if (conflict1 == None and conflict2 == None) and (conflict3 == None):
                event = Event("1", _room_id, _date, _start_t, _end_t,
                                _organiser, _participant, _purpose, _remark)
                # 待處理
                newEvent = gapi.main(event, session['username'])
                event.event_id = newEvent['id']
                print("新事件", newEvent)
                db.session.add(event)
                db.session.commit()

                # 發送會議建立通知信
                p2_list.append(session['username'])
                event_type = 0
                send_email(event_type, p2_list, _room_id, _date, _start_t, _end_t, _organiser, _purpose, _remark)
                
            else:
                # 需要將錯誤訊息回傳網頁
                error = "The reservation conflicts with other existing meetings."
                print(error)
                flash(error, 'info')
        return render_template("Inquire.html", error=error, login_or_not=login_or_not, login=login)
    else:
        return redirect(url_for("login"))

@app.route('/after_login')
def after_login():
    return render_template("after_login.html")


# 註冊頁面
@app.route('/auth/register', methods=('GET', 'POST'))
def register():
    if 'username' in session:
        login = "Hi!, {username} (logout)".format(username=session['username'])
        login_or_not = "/logout"
    else:
        login_or_not = '/auth/login'
        login = 'login'

    error = None
    if request.method == 'POST':
        error = None
        # 從表單取得使用者輸入的帳戶資料
        username = request.form['Username']
        password = request.form['Password']
        check = request.form['Check_Password']
        print(username)
        print(password)

        if not username:
            error = 'Username is required.'
        elif not password:
            error = 'Password is required.'
        elif password != check:
            error = 'Password and check is inconsistent'

        if error is None:
            try:
                # 新增使用者資料進入帳戶資料庫
                _account = Account(username, generate_password_hash(password))
                db.session.add(_account)
                db.session.commit()
            except exc.IntegrityError:
                # 如果使用者因重複註冊而發生錯誤，則還原資料庫
                error = f"User {username} is already registered."
                db.session.rollback()
            return redirect(url_for("login"))
        else:
            flash(error, 'info')
            return redirect(url_for("register"))
    return render_template('auth/register.html', error=error, login_or_not=login_or_not, login=login)


# 登入頁面
@app.route('/auth/login', methods=('GET', 'POST'))
def login():
    login_or_not = '/auth/login'
    login = 'login'
    error = None
    if request.method == 'POST':
        found_user = None
        username = request.form['Username']
        password = request.form['Password']

        # 尋找資料庫內是否有帳號名稱相符的使用者資料
        found_user = Account.query.filter_by(name=username).first()

        if found_user is None:
            error = 'Incorrect username.'
        elif not check_password_hash(found_user.password, password):
            error = 'Incorrect password.'
            
        if error is None:
            # 登入成功，紀錄登入狀態
            session.clear()
            session['user_id'] = found_user.id
            session['username'] = username
            return redirect(url_for('after_login'))
        else:
            flash(error, "info")
            return redirect(url_for("login"))
    return render_template('auth/login.html', error=error, login_or_not=login_or_not, login=login)


'''
@app.before_app_request
def load_logged_in_user():
    user_id = session.get('user_id')

    if user_id is None:
        g.user = None
    else:
        g.user = get_it.db().execute(
            'SELECT * FROM user WHERE id = ?', (user_id,)
        ).fetchone()
'''

# 登出網頁
@app.route('/logout')
def logout():
    # 刪除登入狀態
    if os.path.isfile('token{name}.json'.format(name=session['username'])):
        os.remove('token{name}.json'.format(name=session['username']))
    session.clear()
    return redirect(url_for('login'))


if __name__=='__main__':
    app.run()
